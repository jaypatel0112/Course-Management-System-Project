package com.CourseManagementSystem.myappvs.courseDescription;

import com.CourseManagementSystem.myappvs.courseCatalog.Catalog;

public interface CourseDescriptionService {
    CourseDescriptionDto getCourseDetail(Long courseId);

}
