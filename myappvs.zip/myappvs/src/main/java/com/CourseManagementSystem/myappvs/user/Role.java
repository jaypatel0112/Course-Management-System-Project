package com.CourseManagementSystem.myappvs.user;

public enum Role {
    USER,
    ADMIN
}
