/**
 * The user's entity
 * <li>One to one relationship between user and student.
 * <li>There is login set up for user too.
 * 
 * @author Jay Rashmitbhai Patel
 */
package com.CourseManagementSystem.myappvs.user;
