package com.CourseManagementSystem.myappvs.courseCatalog;

public class CourseEnrollmentRequest {
    private String courseId;

    // Getters and Setters
    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
}
