/**
 * This package helps to display the data of the particular user which signed
 * in.
 * 
 * @author Jay Rashmitbhai Patel
 */

package com.CourseManagementSystem.myappvs.profile;
