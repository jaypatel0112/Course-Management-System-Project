/**
 * The Event's entity
 * 
 * @author Jay Rashmitbhai Patel
 */
package com.CourseManagementSystem.myappvs.event;
