/**
 * The student's entity
 * <li>One to one relationship between student and user.
 * 
 * @author Jay Rashmitbhai Patel
 */
package com.CourseManagementSystem.myappvs.student;
