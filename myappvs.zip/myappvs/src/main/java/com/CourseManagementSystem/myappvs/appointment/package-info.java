
/**
 * The appointment entity
 * <li>Many to one relationship between appointment and student
 * <li>Many to one relationship between appointment and advisor
 * 
 * @author Guntaka Satish Harshavardhan Reddy
 */
package com.CourseManagementSystem.myappvs.appointment;
