
/**
 * The advisor entity
 * <li>One to many relationship between advisor and appointment  
 * 
 * @author Guntaka Satish Harshavardhan Reddy
 */
package com.CourseManagementSystem.myappvs.advsior;
