package com.CourseManagementSystem.myappvs.user;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface Userservice {
    UserDetailsService userDetailsService();
}
