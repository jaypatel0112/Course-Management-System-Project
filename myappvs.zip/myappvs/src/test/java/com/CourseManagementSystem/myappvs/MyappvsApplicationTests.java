package com.CourseManagementSystem.myappvs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyappvsApplicationTests {

	@Test
	void contextLoads() {
	}

}
